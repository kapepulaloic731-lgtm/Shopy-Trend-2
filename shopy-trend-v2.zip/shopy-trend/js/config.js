// ===== CONFIGURATION — le seul endroit à modifier pour le numéro WhatsApp =====
const CONFIG = {
  whatsapp: "243000000000", // numéro WhatsApp de la boutique (format international, sans + ni espaces)
  currency: "$",
  payments: ["Paiement à la livraison", "Mobile Money", "Carte bancaire"]
};
